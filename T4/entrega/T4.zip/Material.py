class Material:
    def __init__(self,diffuse,specular,reflection):
        self.diffuse = diffuse
        self.specular = specular
        self.reflection = reflection
